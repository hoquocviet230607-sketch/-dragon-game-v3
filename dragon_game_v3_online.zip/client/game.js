let WS_URL=localStorage.getItem("dragon_ws")||"wss://YOUR-SERVER-DOMAIN";
let ws=null,token=localStorage.getItem("dragon_token");
const auth=document.getElementById("auth"),ui=document.getElementById("gameUI"),status=document.getElementById("status");
const canvas=document.getElementById("game"),ctx=canvas.getContext("2d"),stats=document.getElementById("stats"),notice=document.getElementById("notice");
let me=null,players=[],enemies=[],keys={up:false,down:false,left:false,right:false},lastMove=0;

function connect(){
  if(location.protocol==="file:") { status.textContent="Hãy mở client por uma hospedagem HTTPS."; return; }
  ws=new WebSocket(WS_URL);
  ws.onopen=()=>{status.textContent="Đã kết nối server.";if(token)send({type:"enter",token})};
  ws.onclose=()=>{if(!ui.classList.contains("hidden"))say("Mất kết nối server.");};
  ws.onmessage=e=>{
    const m=JSON.parse(e.data);
    if(m.type==="error")status.textContent=m.message;
    if(m.type==="registered")status.textContent=m.message+" Hãy đăng nhập.";
    if(m.type==="login_ok"){token=m.token;localStorage.setItem("dragon_token",token);send({type:"enter",token})}
    if(m.type==="world"){me=m.me;players=m.state.players;enemies=m.state.enemies;auth.classList.add("hidden");ui.classList.remove("hidden");resize()}
    if(m.type==="state"){players=m.players;enemies=m.enemies;if(me){const x=players.find(p=>p.id===me.id);if(x)me=x}}
    if(m.type==="profile"){me=m.me}
    if(m.type==="combat")say(m.message);
  };
}
function send(x){if(ws&&ws.readyState===1)ws.send(JSON.stringify(x))}
document.getElementById("login").onclick=()=>send({type:"login",username:username.value,password:password.value});
document.getElementById("register").onclick=()=>send({type:"register",username:username.value,password:password.value,name:charName.value});
document.getElementById("logout").onclick=()=>{localStorage.removeItem("dragon_token");location.reload()};
document.querySelectorAll("[data-k]").forEach(b=>{
 const k=b.dataset.k;
 b.addEventListener("pointerdown",e=>{e.preventDefault();keys[k]=true},{passive:false});
 ["pointerup","pointercancel","pointerleave"].forEach(ev=>b.addEventListener(ev,()=>keys[k]=false));
});
document.getElementById("attack").onclick=()=>send({type:"attack"});
addEventListener("keydown",e=>{let k=e.key.toLowerCase();if(k==="w"||k==="arrowup")keys.up=true;if(k==="s"||k==="arrowdown")keys.down=true;if(k==="a"||k==="arrowleft")keys.left=true;if(k==="d"||k==="arrowright")keys.right=true;if(e.key===" ")send({type:"attack"})});
addEventListener("keyup",e=>{let k=e.key.toLowerCase();if(k==="w"||k==="arrowup")keys.up=false;if(k==="s"||k==="arrowdown")keys.down=false;if(k==="a"||k==="arrowleft")keys.left=false;if(k==="d"||k==="arrowright")keys.right=false});

function resize(){canvas.width=innerWidth*devicePixelRatio;canvas.height=(innerHeight-52)*devicePixelRatio;canvas.style.width=innerWidth+"px";canvas.style.height=(innerHeight-52)+"px";ctx.setTransform(devicePixelRatio,0,0,devicePixelRatio,0,0)}
addEventListener("resize",resize);resize();

function say(t){notice.textContent=t;notice.classList.add("show");clearTimeout(say.t);say.t=setTimeout(()=>notice.classList.remove("show"),1200)}
function loop(){
 requestAnimationFrame(loop);
 if(!me)return;
 if(Date.now()-lastMove>70){
  let dx=(keys.right?1:0)-(keys.left?1:0),dy=(keys.down?1:0)-(keys.up?1:0);
  if(dx||dy){send({type:"move",dx,dy});lastMove=Date.now()}
 }
 const W=innerWidth,H=innerHeight-52,camX=Math.max(0,Math.min(2400-W,me.x-W/2)),camY=Math.max(0,Math.min(1400-H,me.y-H/2));
 ctx.clearRect(0,0,W,H);ctx.fillStyle="#315d35";ctx.fillRect(0,0,W,H);
 ctx.strokeStyle="#ffffff12";for(let x=-camX%80;x<W;x+=80){ctx.beginPath();ctx.moveTo(x,0);ctx.lineTo(x,H);ctx.stroke()}for(let y=-camY%80;y<H;y+=80){ctx.beginPath();ctx.moveTo(0,y);ctx.lineTo(W,y);ctx.stroke()}
 for(const e of enemies)if(e.alive){const x=e.x-camX,y=e.y-camY;ctx.beginPath();ctx.arc(x,y,23,0,7);ctx.fillStyle=e.id===3?"#777":"#45a85a";ctx.fill();ctx.fillStyle="#222";ctx.fillRect(x-25,y-36,50,5);ctx.fillStyle="#e65b5b";ctx.fillRect(x-25,y-36,50*(e.hp/e.maxHp),5);ctx.fillStyle="#fff";ctx.font="12px Arial";ctx.textAlign="center";ctx.fillText(e.name,x,y-44)}
 for(const p of players){const x=p.x-camX,y=p.y-camY;ctx.beginPath();ctx.arc(x,y,20,0,7);ctx.fillStyle=p.id===me.id?"#ffd447":"#4ea7ff";ctx.fill();ctx.fillStyle="#fff";ctx.font="13px Arial";ctx.textAlign="center";ctx.fillText(p.name,x,y-29)}
 stats.textContent=`${me.name} • Lv.${me.level} • HP ${me.hp}/${me.maxHp} • EXP ${me.exp}/${me.level*100}`;
}
connect();loop();