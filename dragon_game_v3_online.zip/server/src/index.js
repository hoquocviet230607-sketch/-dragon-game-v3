const http=require("http");
const {WebSocketServer}=require("ws");
const bcrypt=require("bcryptjs");
const jwt=require("jsonwebtoken");
const db=require("./db");
const world=require("./world");

const PORT=Number(process.env.PORT||8080);
const JWT_SECRET=process.env.JWT_SECRET||"CHANGE_ME_IN_PRODUCTION";

const server=http.createServer((req,res)=>{
  res.writeHead(200,{"Content-Type":"application/json; charset=utf-8"});
  res.end(JSON.stringify({ok:true,name:"Dragon Game V3",multiplayer:true}));
});
const wss=new WebSocketServer({server});

const accountByToken=new Map();

function send(ws,type,data={}){
  if(ws.readyState===1) ws.send(JSON.stringify({type,...data}));
}
function broadcast(type,data={}){
  const out=JSON.stringify({type,...data});
  for(const ws of wss.clients) if(ws.readyState===1) ws.send(out);
}
function cleanName(s){
  return String(s||"").trim().replace(/[^\wÀ-ỹ ]/g,"").slice(0,20);
}
function makeToken(accountId){
  return jwt.sign({accountId},JWT_SECRET,{expiresIn:"7d"});
}
function auth(token){
  try{return jwt.verify(token,JWT_SECRET)}catch{return null}
}
function characterFor(accountId){
  return db.prepare("SELECT * FROM characters WHERE account_id=?").get(accountId);
}
function savePlayer(p){
  db.prepare(`UPDATE characters SET level=?,exp=?,hp=?,max_hp=?,x=?,y=?,gold=?,potion=?,sword=? WHERE id=?`)
    .run(p.level,p.exp,p.hp,p.maxHp,p.x,p.y,p.gold,p.potion,p.sword,p.id);
}

wss.on("connection",ws=>{
  ws.player=null;

  ws.on("message",raw=>{
    try{
      const m=JSON.parse(raw.toString());

      if(m.type==="register"){
        const username=String(m.username||"").trim();
        const password=String(m.password||"");
        const name=cleanName(m.name||username);
        if(!/^[A-Za-z0-9_]{3,20}$/.test(username))
          return send(ws,"error",{message:"Tên đăng nhập 3-20 ký tự, chỉ chữ/số/_."});
        if(password.length<6)
          return send(ws,"error",{message:"Mật khẩu tối thiểu 6 ký tự."});
        if(!name) return send(ws,"error",{message:"Tên nhân vật không hợp lệ."});
        if(db.prepare("SELECT id FROM accounts WHERE username=?").get(username))
          return send(ws,"error",{message:"Tài khoản đã tồn tại."});

        const hash=bcrypt.hashSync(password,10);
        const info=db.prepare("INSERT INTO accounts(username,password_hash) VALUES(?,?)").run(username,hash);
        db.prepare("INSERT INTO characters(account_id,name) VALUES(?,?)").run(info.lastInsertRowid,name);
        return send(ws,"registered",{message:"Đăng ký thành công."});
      }

      if(m.type==="login"){
        const row=db.prepare("SELECT * FROM accounts WHERE username=?").get(String(m.username||"").trim());
        if(!row||!bcrypt.compareSync(String(m.password||""),row.password_hash))
          return send(ws,"error",{message:"Sai tài khoản hoặc mật khẩu."});
        const token=makeToken(row.id);
        const c=characterFor(row.id);
        return send(ws,"login_ok",{token,character:{
          name:c.name,level:c.level,exp:c.exp,hp:c.hp,maxHp:c.max_hp,
          x:c.x,y:c.y,gold:c.gold,potion:c.potion,sword:c.sword
        }});
      }

      if(m.type==="enter"){
        const payload=auth(String(m.token||""));
        if(!payload)return send(ws,"error",{message:"Phiên đăng nhập hết hạn."});
        const c=characterFor(payload.accountId);
        if(!c)return send(ws,"error",{message:"Không tìm thấy nhân vật."});
        const p={
          id:c.id,accountId:c.account_id,name:c.name,level:c.level,exp:c.exp,hp:c.hp,
          maxHp:c.max_hp,x:c.x,y:c.y,gold:c.gold,potion:c.potion,sword:c.sword
        };
        ws.player=p; world.players.set(p.id,p);
        send(ws,"world",{me:world.publicPlayer(p),state:world.snapshot(),inventory:{gold:p.gold,potion:p.potion,sword:p.sword}});
        broadcast("state",world.snapshot());
        return;
      }

      if(m.type==="move"&&ws.player){
        let dx=Math.max(-1,Math.min(1,Number(m.dx)||0));
        let dy=Math.max(-1,Math.min(1,Number(m.dy)||0));
        const len=Math.hypot(dx,dy); if(len){dx/=len;dy/=len;}
        const speed=9;
        ws.player.x=Math.max(30,Math.min(world.WORLD.w-30,ws.player.x+dx*speed));
        ws.player.y=Math.max(30,Math.min(world.WORLD.h-30,ws.player.y+dy*speed));
        savePlayer(ws.player);
        broadcast("state",world.snapshot());
        return;
      }

      if(m.type==="attack"&&ws.player){
        let target=null,best=Infinity;
        for(const e of world.enemies){
          if(e.hp<=0)continue;
          const d=Math.hypot(e.x-ws.player.x,e.y-ws.player.y);
          if(d<90&&d<best){best=d;target=e;}
        }
        if(!target)return send(ws,"combat",{message:"Không có quái trong tầm."});
        const damage=20+ws.player.sword*5;
        target.hp-=damage;
        if(target.hp<=0){
          target.hp=0;
          ws.player.gold+=5+Math.floor(Math.random()*11);
          ws.player.exp+=35;
          while(ws.player.exp>=ws.player.level*100){
            ws.player.exp-=ws.player.level*100;
            ws.player.level++;
            ws.player.maxHp+=20;
            ws.player.hp=ws.player.maxHp;
          }
          setTimeout(()=>{target.hp=target.maxHp;broadcast("state",world.snapshot())},8000);
        }
        savePlayer(ws.player);
        send(ws,"combat",{message:`Gây ${damage} sát thương.`});
        send(ws,"profile",{me:world.publicPlayer(ws.player),inventory:{gold:ws.player.gold,potion:ws.player.potion,sword:ws.player.sword}});
        broadcast("state",world.snapshot());
      }
    }catch(e){
      console.error(e);
      send(ws,"error",{message:"Dữ liệu gửi lên không hợp lệ."});
    }
  });

  ws.on("close",()=>{
    if(ws.player){
      savePlayer(ws.player);
      world.players.delete(ws.player.id);
      broadcast("state",world.snapshot());
    }
  });
});

server.listen(PORT,()=>console.log(`Dragon Game V3 listening on :${PORT}`));