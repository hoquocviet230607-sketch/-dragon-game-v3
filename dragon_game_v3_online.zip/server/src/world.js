const players = new Map();
const enemies = [
  {id:1,x:900,y:600,hp:50,maxHp:50,name:"Sóc rừng"},
  {id:2,x:1500,y:650,hp:70,maxHp:70,name:"Quái xanh"},
  {id:3,x:1750,y:900,hp:90,maxHp:90,name:"Quái đá"},
  {id:4,x:800,y:950,hp:50,maxHp:50,name:"Sóc rừng"}
];
const WORLD={w:2400,h:1400};

function publicPlayer(p){
  return {id:p.id,name:p.name,level:p.level,exp:p.exp,hp:p.hp,maxHp:p.maxHp,x:p.x,y:p.y};
}
function snapshot(){
  return {
    players:[...players.values()].map(publicPlayer),
    enemies:enemies.map(e=>({id:e.id,x:e.x,y:e.y,hp:e.hp,maxHp:e.maxHp,name:e.name,alive:e.hp>0}))
  };
}
module.exports={players,enemies,WORLD,publicPlayer,snapshot};