const players = new Map();
const enemies = [
  {id:1,x:560,y:430,hp:60,maxHp:60,name:"Slime xanh",reward:8,exp:30,respawn:0},
  {id:2,x:920,y:520,hp:85,maxHp:85,name:"Sóc đá",reward:12,exp:42,respawn:0},
  {id:3,x:1370,y:430,hp:120,maxHp:120,name:"Quái rừng",reward:16,exp:55,respawn:0},
  {id:4,x:1760,y:690,hp:150,maxHp:150,name:"Quái đá",reward:22,exp:70,respawn:0},
  {id:5,x:720,y:1050,hp:100,maxHp:100,name:"Dơi đêm",reward:15,exp:50,respawn:0},
  {id:6,x:1500,y:1060,hp:180,maxHp:180,name:"Hộ vệ đá",reward:25,exp:85,respawn:0},
  {id:7,x:2050,y:900,hp:420,maxHp:420,name:"BOSS Golem",reward:120,exp:350,boss:true,respawn:0}
];
const WORLD={w:2400,h:1400};
const zones=[
  {id:"village",name:"Làng Bình Minh",x:80,y:80,w:500,h:300,color:"#6f9b57"},
  {id:"forest",name:"Rừng Xanh",x:500,y:250,w:850,h:700,color:"#3d7d48"},
  {id:"rock",name:"Thung Lũng Đá",x:1300,y:300,w:1000,h:1000,color:"#5d5f55"}
];
function publicPlayer(p){return {id:p.id,name:p.name,level:p.level,exp:p.exp,hp:p.hp,maxHp:p.maxHp,x:p.x,y:p.y,power:p.power,kills:p.kills};}
function snapshot(){return {players:[...players.values()].map(publicPlayer),enemies:enemies.map(e=>({id:e.id,x:e.x,y:e.y,hp:e.hp,maxHp:e.maxHp,name:e.name,alive:e.hp>0,boss:!!e.boss}))};}
module.exports={players,enemies,WORLD,zones,publicPlayer,snapshot};
