const Database = require("better-sqlite3");
const path = require("path");
const fs = require("fs");

const dataDir = process.env.DATA_DIR || path.join(__dirname,"..","data");
fs.mkdirSync(dataDir,{recursive:true});
const db = new Database(path.join(dataDir,"dragon.db"));
db.pragma("journal_mode = WAL");
db.pragma("foreign_keys = ON");

db.exec(`
CREATE TABLE IF NOT EXISTS accounts(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  username TEXT NOT NULL UNIQUE,
  password_hash TEXT NOT NULL,
  created_at TEXT DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS characters(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  account_id INTEGER NOT NULL UNIQUE,
  name TEXT NOT NULL,
  level INTEGER NOT NULL DEFAULT 1,
  exp INTEGER NOT NULL DEFAULT 0,
  hp INTEGER NOT NULL DEFAULT 120,
  max_hp INTEGER NOT NULL DEFAULT 120,
  x REAL NOT NULL DEFAULT 1200,
  y REAL NOT NULL DEFAULT 700,
  gold INTEGER NOT NULL DEFAULT 50,
  potion INTEGER NOT NULL DEFAULT 5,
  sword INTEGER NOT NULL DEFAULT 1,
  power INTEGER NOT NULL DEFAULT 10,
  kills INTEGER NOT NULL DEFAULT 0,
  FOREIGN KEY(account_id) REFERENCES accounts(id) ON DELETE CASCADE
);
`);

// Safe migration for V3 databases.
for (const [name, ddl] of [
  ["power","ALTER TABLE characters ADD COLUMN power INTEGER NOT NULL DEFAULT 10"],
  ["kills","ALTER TABLE characters ADD COLUMN kills INTEGER NOT NULL DEFAULT 0"]
]) {
  try { db.prepare(`SELECT ${name} FROM characters LIMIT 1`).get(); }
  catch { db.exec(ddl); }
}
module.exports = db;
