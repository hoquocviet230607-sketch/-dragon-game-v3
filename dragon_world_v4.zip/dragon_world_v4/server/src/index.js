const http=require("http");
const fs=require("fs");
const path=require("path");
const {WebSocketServer}=require("ws");
const bcrypt=require("bcryptjs");
const jwt=require("jsonwebtoken");
const db=require("./db");
const world=require("./world");
const PORT=Number(process.env.PORT||8080);
const JWT_SECRET=process.env.JWT_SECRET||"CHANGE_ME_IN_PRODUCTION";
const clientDir=path.join(__dirname,"../../client");
const mime={".html":"text/html; charset=utf-8",".js":"text/javascript; charset=utf-8",".css":"text/css; charset=utf-8",".json":"application/json; charset=utf-8",".png":"image/png",".jpg":"image/jpeg",".svg":"image/svg+xml"};

const server=http.createServer((req,res)=>{
  if(req.url==="/health"||req.url==="/api/health"){
    res.writeHead(200,{"Content-Type":"application/json; charset=utf-8"});
    return res.end(JSON.stringify({ok:true,name:"Dragon World V4",players:world.players.size}));
  }
  let reqPath=decodeURIComponent((req.url||"/").split("?")[0]);
  if(reqPath==="/") reqPath="/index.html";
  const file=path.normalize(path.join(clientDir,reqPath));
  if(!file.startsWith(clientDir)||!fs.existsSync(file)||!fs.statSync(file).isFile()){
    res.writeHead(404);return res.end("Not found");
  }
  res.writeHead(200,{"Content-Type":mime[path.extname(file)]||"application/octet-stream","Cache-Control":"no-cache"});
  fs.createReadStream(file).pipe(res);
});
const wss=new WebSocketServer({server});
function send(ws,type,data={}){if(ws.readyState===1)ws.send(JSON.stringify({type,...data}));}
function broadcast(type,data={}){const out=JSON.stringify({type,...data});for(const ws of wss.clients)if(ws.readyState===1)ws.send(out);}
function cleanName(s){return String(s||"").trim().replace(/[^\wÀ-ỹ ]/g,"").slice(0,20);}
function tokenFor(id){return jwt.sign({accountId:id},JWT_SECRET,{expiresIn:"7d"});}
function auth(t){try{return jwt.verify(t,JWT_SECRET)}catch{return null}}
function characterFor(accountId){return db.prepare("SELECT * FROM characters WHERE account_id=?").get(accountId);}
function playerFrom(c){return {id:c.id,accountId:c.account_id,name:c.name,level:c.level,exp:c.exp,hp:c.hp,maxHp:c.max_hp,x:c.x,y:c.y,gold:c.gold,potion:c.potion,sword:c.sword,power:c.power,kills:c.kills};}
function savePlayer(p){db.prepare(`UPDATE characters SET level=?,exp=?,hp=?,max_hp=?,x=?,y=?,gold=?,potion=?,sword=?,power=?,kills=? WHERE id=?`).run(p.level,p.exp,p.hp,p.maxHp,p.x,p.y,p.gold,p.potion,p.sword,p.power,p.kills,p.id);}
function profile(p){return {me:world.publicPlayer(p),inventory:{gold:p.gold,potion:p.potion,sword:p.sword,power:p.power,kills:p.kills}};}
function levelUp(p){let leveled=0;while(p.exp>=p.level*100){p.exp-=p.level*100;p.level++;p.maxHp+=25;p.hp=p.maxHp;p.power+=3;leveled++;}return leveled;}
function distance(a,b){return Math.hypot(a.x-b.x,a.y-b.y)}
function nearbyEnemy(p){let best=null,d=Infinity;for(const e of world.enemies){if(e.hp<=0)continue;const x=distance(p,e);if(x<95&&x<d){d=x;best=e;}}return best;}

wss.on("connection",ws=>{
  ws.player=null;ws.lastMove=0;ws.lastAttack=0;ws.isAlive=true;
  ws.on("pong",()=>ws.isAlive=true);
  send(ws,"hello",{name:"Dragon World V4"});
  ws.on("message",raw=>{
    try{
      const m=JSON.parse(raw.toString());
      if(m.type==="register"){
        const username=String(m.username||"").trim(),password=String(m.password||""),name=cleanName(m.name||username);
        if(!/^[A-Za-z0-9_]{3,20}$/.test(username))return send(ws,"error",{message:"Tên đăng nhập 3-20 ký tự, chỉ chữ/số/_"});
        if(password.length<6)return send(ws,"error",{message:"Mật khẩu tối thiểu 6 ký tự."});
        if(!name)return send(ws,"error",{message:"Tên nhân vật không hợp lệ."});
        if(db.prepare("SELECT id FROM accounts WHERE username=?").get(username))return send(ws,"error",{message:"Tài khoản đã tồn tại."});
        const hash=bcrypt.hashSync(password,10);const info=db.prepare("INSERT INTO accounts(username,password_hash) VALUES(?,?)").run(username,hash);
        db.prepare("INSERT INTO characters(account_id,name) VALUES(?,?)").run(info.lastInsertRowid,name);
        return send(ws,"registered",{message:"Đăng ký thành công."});
      }
      if(m.type==="login"){
        const row=db.prepare("SELECT * FROM accounts WHERE username=?").get(String(m.username||"").trim());
        if(!row||!bcrypt.compareSync(String(m.password||""),row.password_hash))return send(ws,"error",{message:"Sai tài khoản hoặc mật khẩu."});
        const c=characterFor(row.id);return send(ws,"login_ok",{token:tokenFor(row.id),character:playerFrom(c)});
      }
      if(m.type==="enter"){
        const payload=auth(String(m.token||""));if(!payload)return send(ws,"error",{message:"Phiên đăng nhập hết hạn."});
        const c=characterFor(payload.accountId);if(!c)return send(ws,"error",{message:"Không tìm thấy nhân vật."});
        const p=playerFrom(c);p.hp=Math.min(p.hp,p.maxHp);ws.player=p;world.players.set(p.id,p);
        send(ws,"world",{me:world.publicPlayer(p),state:world.snapshot(),zones:world.zones,inventory:{gold:p.gold,potion:p.potion,sword:p.sword,power:p.power,kills:p.kills}});broadcast("state",world.snapshot());return;
      }
      if(!ws.player)return;
      const p=ws.player;
      if(m.type==="move"){
        const now=Date.now();if(now-ws.lastMove<55)return;ws.lastMove=now;
        let dx=Math.max(-1,Math.min(1,Number(m.dx)||0)),dy=Math.max(-1,Math.min(1,Number(m.dy)||0));const len=Math.hypot(dx,dy);if(len){dx/=len;dy/=len;}
        const speed=10+(p.level-1)*0.15;p.x=Math.max(25,Math.min(world.WORLD.w-25,p.x+dx*speed));p.y=Math.max(25,Math.min(world.WORLD.h-25,p.y+dy*speed));savePlayer(p);broadcast("state",world.snapshot());return;
      }
      if(m.type==="attack"){
        const now=Date.now();if(now-ws.lastAttack<350)return;ws.lastAttack=now;
        const e=nearbyEnemy(p);if(!e)return send(ws,"combat",{message:"Không có quái trong tầm đánh."});
        const damage=18+p.power+p.sword*6; e.hp=Math.max(0,e.hp-damage);
        if(e.hp===0){p.gold+=e.reward;p.exp+=e.exp;p.kills++;const up=levelUp(p);e.respawn=Date.now()+(e.boss?30000:7000);send(ws,"combat",{message:`-${damage} HP • +${e.exp} EXP • +${e.reward} vàng${up?` • Lên ${p.level}!`:""}`});}
        else send(ws,"combat",{message:`Gây ${damage} sát thương.`});
        savePlayer(p);send(ws,"profile",profile(p));broadcast("state",world.snapshot());return;
      }
      if(m.type==="use_potion"){
        if(p.potion<=0)return send(ws,"error",{message:"Hết bình hồi phục."});
        if(p.hp>=p.maxHp)return send(ws,"error",{message:"HP đang đầy."});p.potion--;p.hp=Math.min(p.maxHp,p.hp+80);savePlayer(p);send(ws,"profile",profile(p));send(ws,"combat",{message:"Đã hồi 80 HP."});broadcast("state",world.snapshot());return;
      }
      if(m.type==="shop"){
        const item=String(m.item||"");
        if(item==="potion"){
          if(p.gold<15)return send(ws,"error",{message:"Không đủ vàng (15 vàng/bình)."});p.gold-=15;p.potion++;
        } else if(item==="sword"){
          const price=80*p.sword;if(p.gold<price)return send(ws,"error",{message:`Cần ${price} vàng để nâng vũ khí.`});p.gold-=price;p.sword++;
        } else return;
        savePlayer(p);send(ws,"profile",profile(p));send(ws,"combat",{message:"Mua/nâng cấp thành công."});return;
      }
      if(m.type==="chat"){
        const text=String(m.text||"").trim().slice(0,120);if(text)broadcast("chat",{name:p.name,text});return;
      }
    }catch(e){console.error(e);send(ws,"error",{message:"Dữ liệu gửi lên không hợp lệ."});}
  });
  ws.on("close",()=>{if(ws.player){savePlayer(ws.player);world.players.delete(ws.player.id);broadcast("state",world.snapshot());}});
});
setInterval(()=>{
  for(const e of world.enemies)if(e.hp<=0&&e.respawn&&Date.now()>=e.respawn){e.hp=e.maxHp;e.respawn=0;}
  broadcast("state",world.snapshot());
},1000);
const heartbeat=setInterval(()=>{for(const ws of wss.clients){if(ws.isAlive===false){ws.terminate();continue}ws.isAlive=false;ws.ping();}},30000);
wss.on("close",()=>clearInterval(heartbeat));
server.listen(PORT,()=>console.log(`Dragon World V4 listening on :${PORT}`));
