# Dragon World V4 Online

Bản V4 là game nhập vai online nguyên bản, dùng gameplay fantasy tương tự thể loại MMORPG nhưng không dùng tên/nhân vật/asset có bản quyền của game khác.

## Có gì mới
- Multiplayer WebSocket realtime.
- Server-authoritative movement và combat.
- 7 loại quái, có BOSS với thời gian hồi sinh.
- EXP, level-up, tăng HP và sức mạnh.
- Vàng, bình hồi HP, nâng cấp vũ khí.
- Chat realtime.
- Khu vực/map màu, tên vùng.
- Heartbeat WebSocket + reconnect client.
- Rate limit cơ bản cho di chuyển/đánh.
- SQLite migration tự động từ database V3.
- Server Node.js phục vụ luôn cả client, không cần host riêng frontend.
- `/health` để kiểm tra server.

## Chạy
```bash
cd server
npm install
JWT_SECRET="thay-bang-chuoi-bi-mat-dai" npm start
```
Mở `http://localhost:8080`.

## Deploy
Host Node.js hỗ trợ WebSocket và persistent disk. Đặt:
- `PORT`: port do host cấp.
- `JWT_SECRET`: chuỗi bí mật dài, không dùng giá trị mặc định.
- `DATA_DIR`: thư mục persistent nếu host yêu cầu.

Client tự dùng `ws://` hoặc `wss://` theo giao thức của trang, nên không cần sửa domain trong `game.js` khi server và client chạy cùng host.

## Điều khiển
- Điện thoại: D-pad + nút Đánh.
- PC: WASD/phím mũi tên + Space để đánh.
- 🧪 Hồi HP: dùng bình.
- 🪙 Mua bình: 15 vàng.
- ⚔️ Nâng vũ khí: giá tăng theo cấp.
- Chat: nhập tin nhắn trong bảng bên phải.

## Lưu ý
Đây là nền tảng game gốc. Nếu muốn phát hành công khai, nên bổ sung HTTPS, backup database, giới hạn đăng nhập, chống spam/chat abuse, moderation, admin panel và hệ thống tài khoản/email trước khi mở rộng người chơi.
